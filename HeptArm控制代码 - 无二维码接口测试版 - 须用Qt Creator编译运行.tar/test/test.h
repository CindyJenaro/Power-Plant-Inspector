#ifndef test_H
#define test_H

#include <EwayFunc/FuncInterface.h>

Declare_FunLibSymble

class test:public CFuncInterface
{
private:
    ebool Zero_flag;
    ebool moro2_flag = false;
    eint count;
public:
    test() {}
    virtual ~test() {}
    virtual eint Initialize(std::vector<eint> &vFeatureList,ebool &bLimbAuthority,edouble &dTimeOut);
    virtual eint Destroy();
    virtual eint CheckMsgCode(eint nMsgCode);

    virtual void JobStart();
    virtual void JobFailed(eint nErrCode);

    virtual eint ProcTimer(edouble dTimeStamp);
    virtual eint ProcMotCmdDone(edouble dTimeStamp,CCmdDoneMessage* piCmdDone);

    virtual eint ProcArmPos(edouble dTimeStamp,CArmPosMessage* piArmPos);
    inline eint PosOrig();
    inline eint PosFolded();
    inline eint PosWorking();
    inline eint PosSnake();
    DECLEAR_FIFMESSAGE_MAP
};

#endif // test_H


