#include "test.h"
#include <EwayFunc/FuncSdkLib.h>
#include <iostream>

#define pi 3.14

Declare_FunSdk_Lib(test)
Declare_Function_ID("88dfbb1d-499e-48b2-b38d-c85408d79665")
Declare_Function_Priority(FunPri_Normal)

RegisterMessage_Start
RegisterMessage_End

BEGIN_FIFEMSG_MAP(test,CFuncInterface)
//MSG_FIFMAP(FunMsg_User+1,OnMessageProcess)
END_FIFMSG_MAP

eint test::Initialize(std::vector<eint> &vFeatureList,ebool &bLimbAuthority,edouble &dTimeOut)
{
//    vFeatureList.resize(1);
//    vFeatureList[0] = SysCom_ID_LMsg_ArmPos;
    bLimbAuthority = true;
    SetTimer(100);
    return ERR_NONE;
}

eint test::Destroy()
{
    return ERR_NONE;
}

eint test::CheckMsgCode(eint nMsgCode)
{
    return MsgProcCode_Notify;
}

void test::JobStart()
{
#ifdef ORIG
    euint unCmdSN;
    CAngleMoveInfo iInfo;
    std::vector<CAngleMoveInfo> arm;
    for(euint m = 0; m < HeptArmJointTotalNum; m++)
    {
        iInfo.Clear ();
        iInfo.m_nServoID = CJointDef::JointID_LArm1 + m;
        iInfo.m_fSpeed = 0.2;
        iInfo.m_fPosition = 0.1;
        arm.push_back (iInfo);
    }
    SendArmGoToAngle (arm, unCmdSN);
#else
    PosFolded();
    PosWorking();
    PosOrig();
    PosSnake();
    PosOrig();
    PosFolded();
#endif

    return ;
}

inline eint test::PosOrig()
{
    euint unCmdSN;
    CAngleMoveInfo iInfo;
    std::vector<CAngleMoveInfo> arm;
    for(euint m = 0; m < HeptArmJointTotalNum; m++)
    {
        iInfo.Clear();
        iInfo.m_nServoID = CJointDef::JointID_LArm1 + m;
        iInfo.m_fSpeed = 1;

        switch(m)
        {
            // THE ORIGIN
            case 0: iInfo.m_fPosition = 0; break; // [-2.6274, 2.6274]
            case 1: iInfo.m_fPosition = 0; break; // [-1.7199, 1.1090]
            case 2: iInfo.m_fPosition = 0; break; // [-2.6100, 2.6100]
            case 3: iInfo.m_fPosition = 0; break; // [-1.7024, 1.7024]
            case 4: iInfo.m_fPosition = 0; break; // [-2.2086, 2.2086]
            case 5: iInfo.m_fPosition = 0; break; // [-1.9991, 1.9991]
            case 6: iInfo.m_fPosition = 0; break; // [-2.0000, 2.0000]
        }

        arm.push_back (iInfo);
    }

    SendArmGoToAngle (arm, unCmdSN);
    // First step finished
    arm.clear();
    sleep(8);
		return ERR_NONE;
}

inline eint test::PosFolded()
{
    euint unCmdSN;
    CAngleMoveInfo iInfo;
    std::vector<CAngleMoveInfo> arm;
    for(euint m = 0; m < HeptArmJointTotalNum; m++)
    {
        iInfo.Clear();
        iInfo.m_nServoID = CJointDef::JointID_LArm1 + m;
        iInfo.m_fSpeed = 1;

        switch(m)
        {
            // FOLDED
            case 0: iInfo.m_fPosition = 2.6274; break; // [-2.6274, 2.6274]
            case 1: iInfo.m_fPosition = pi/6; break; // [-1.7199, 1.1090]
            case 2: iInfo.m_fPosition = -pi/2; break; // [-2.6100, 2.6100]
            case 3: iInfo.m_fPosition = -1.7024; break; // [-1.7024, 1.7024]
            case 4: iInfo.m_fPosition = 0; break; // [-2.2086, 2.2086]
            case 5: iInfo.m_fPosition = -1.7024; break; // [-1.9991, 1.9991]
            case 6: iInfo.m_fPosition = 0; break; // [-2.0000, 2.0000]
            }

        arm.push_back (iInfo);
    }

    SendArmGoToAngle (arm, unCmdSN);
    // Second step finished
    arm.clear();
    sleep(12);
		return ERR_NONE;
}

inline eint test::PosWorking()
{
    euint unCmdSN;
    CAngleMoveInfo iInfo;
    std::vector<CAngleMoveInfo> arm;
    for(euint m = 0; m < HeptArmJointTotalNum; m++)
    {
        iInfo.Clear ();
        iInfo.m_nServoID = CJointDef::JointID_LArm1 + m;
        iInfo.m_fSpeed = 1;

        switch(m)
        {
            // WORKING
            case 0: iInfo.m_fPosition = 0; break; // [-2.6274, 2.6274]
            case 1: iInfo.m_fPosition = -pi/2; break; // [-1.7199, 1.1090]
            case 2: iInfo.m_fPosition = 0; break; // [-2.6100, 2.6100]
            case 3: iInfo.m_fPosition = 0; break; // [-1.7024, 1.7024]
            case 4: iInfo.m_fPosition = pi/2; break; // [-2.2086, 2.2086]
            case 5: iInfo.m_fPosition = 0; break; // [-1.9991, 1.9991]
            case 6: iInfo.m_fPosition = -pi/6; break; // [-2.0000, 2.0000]
        }

        arm.push_back (iInfo);
    }

    SendArmGoToAngle (arm, unCmdSN);
    // Third step finished
    arm.clear();
    sleep(8);
    return ERR_NONE;
}

inline eint test::PosSnake()
{
    euint unCmdSN;
    CAngleMoveInfo iInfo;
    std::vector<CAngleMoveInfo> arm;
    for(euint m = 0; m < HeptArmJointTotalNum; m++)
    {
        iInfo.Clear ();
        iInfo.m_nServoID = CJointDef::JointID_LArm1 + m;
        iInfo.m_fSpeed = 1;

        switch(m)
        {
            // SNAKE
            case 0: iInfo.m_fPosition = pi/2; break; // [-2.6274, 2.6274]
            case 1: iInfo.m_fPosition = -pi/2; break; // [-1.7199, 1.1090]
            case 2: iInfo.m_fPosition = 0; break; // [-2.6100, 2.6100]
            case 3: iInfo.m_fPosition = pi/4; break; // [-1.7024, 1.7024]
            case 4: iInfo.m_fPosition = 0; break; // [-2.2086, 2.2086]
            case 5: iInfo.m_fPosition = -pi/4; break; // [-1.9991, 1.9991]
            case 6: iInfo.m_fPosition = 0; break; // [-2.0000, 2.0000]
        }

        arm.push_back (iInfo);
    }

    SendArmGoToAngle (arm, unCmdSN);
    // Fourth step finished
    arm.clear();
    sleep(8);
    return ERR_NONE;
}

void test::JobFailed(eint nErrCode)
{
    return ;
}

eint  test::ProcTimer(edouble dTimeStamp){
    // std::cout << "logic here" << std::endl;
    return ERR_NONE;
}



eint  test::ProcMotCmdDone(edouble dTimeStamp,CCmdDoneMessage* piCmdDone){

    return ERR_NONE;
}


eint  test::ProcArmPos(edouble dTimeStamp,CArmPosMessage* piArmPos){
    std::cout << "dTimeStamp = " << dTimeStamp << std::endl;

    for(euint i = 0 ; i < piArmPos->m_viArmJointList.size(); i++){
        std::cout << "Position of " << i << " is " << piArmPos->m_viArmJointList[i].m_dPosition << std::endl;

    }
    return ERR_NONE;
}



