#include <EwayFunc/FuncSdkLib.h>
#include "test.h"

int main()
{
   ewayos::FunctionRun("127.0.0.1","test",1);
   return 0;
}
