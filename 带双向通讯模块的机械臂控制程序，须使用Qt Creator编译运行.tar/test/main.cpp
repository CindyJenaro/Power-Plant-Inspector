#include <EwayFunc/FuncSdkLib.h>
#include "test.h"

int main()
{
   ewayos::FunctionRun("192.168.1.30","test",0);
   return 0;
}
