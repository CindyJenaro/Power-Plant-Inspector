#include "test.h"
#include <EwayFunc/FuncSdkLib.h>
#include <iostream>
#include "EwayCore/Commands/ServoTrajCmd.h"

//----------Globals--------------//

SOCKET recv_socket3000;
SOCKET send_socket2000;
char recvline3000[1024] = "";
const double pi = 3.14;
const double aspeed = 0.6; // a moderate angle speed


//----------Some Magic Declarations-------------//

Declare_FunSdk_Lib(test)
Declare_Function_ID("88dfbb1d-499e-48b2-b38d-c85408d79665")
Declare_Function_Priority(FunPri_Normal)

RegisterMessage_Start
RegisterMessage_End

BEGIN_FIFEMSG_MAP(test,CFuncInterface)
//MSG_FIFMAP(FunMsg_User+1,OnMessageProcess)
END_FIFMSG_MAP



//-----------Functions About Socket-------------------//

SOCKET init_recv_socket(int port)
{
	SOCKET RecvSocket;
	RecvSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	
	sockaddr_in AnyAddr;
	AnyAddr.sin_family = AF_INET;
	AnyAddr.sin_port = htons(port);
	AnyAddr.sin_addr.s_addr = htonl(INADDR_ANY);

	bind(RecvSocket, (SOCKADDR*)&AnyAddr, sizeof(AnyAddr));

	timeval tv = {1000, 0};
	setsockopt(RecvSocket, SOL_SOCKET,
        SO_RCVTIMEO, (char*)&tv, sizeof(timeval));

	return RecvSocket;
}

SOCKET init_send_socket(int port)
{
	SOCKET SendSocket;
	SendSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	
	sockaddr_in AnyAddr;
	AnyAddr.sin_family = AF_INET;
	AnyAddr.sin_port = htons(port);
	AnyAddr.sin_addr.s_addr = htonl(INADDR_ANY);

	bind(SendSocket, (SOCKADDR*)&AnyAddr, sizeof(AnyAddr));

	return SendSocket;
}

bool recvfrom_socket(int port, SOCKET socket, char recvline[1024])
{
    sockaddr_in AnyAddr; 
    socklen_t any_addr_length = sizeof(AnyAddr);

    int recv_length = recvfrom(socket, recvline, 1024,
            0, (sockaddr*)&AnyAddr, &any_addr_length);
    if(recv_length > 0)
    {
        printf("recvline: %s\n", recvline);
	    return true;
    }
    else
	    return false;
}

void sendto_socket(int port, SOCKET socket, const char* message)
{
	sockaddr_in ToAddr;
    ToAddr.sin_family = AF_INET;
    ToAddr.sin_port = htons(port);
    ToAddr.sin_addr.s_addr = inet_addr("192.168.1.8");

	static char sendline[1024];

	strcpy(sendline, message);

	int send_length = sendto(socket, sendline, 1024,
		0, (SOCKADDR *)&ToAddr, sizeof(ToAddr));
}

void close_socket(int port, SOCKET socket)
{
    // 关闭socket，结束接收数据
    printf("finished receiving, closing socket of port %d..\n", port);
    close(socket);
}



//-----------------Moro Functions-----------------//

eint test::Initialize(std::vector<eint> &vFeatureList,ebool &bLimbAuthority,edouble &dTimeOut)
{
//    vFeatureList.resize(1);
//    vFeatureList[0] = SysCom_ID_LMsg_ArmPos;
    bLimbAuthority = true;
    SetTimer(100);
    recv_socket3000 = init_recv_socket(3000);
    send_socket2000 = init_send_socket(2000);
    return ERR_NONE;
}

eint test::Destroy()
{
    return ERR_NONE;
}

eint test::CheckMsgCode(eint nMsgCode)
{
    return MsgProcCode_Notify;
}

void test::JobStart()
{
#ifdef ORIG
    euint unCmdSN;
    CAngleMoveInfo iInfo;
    std::vector<CAngleMoveInfo> arm;
    for(euint m = 0; m < HeptArmJointTotalNum; m++)
    {
        iInfo.Clear ();
        iInfo.m_nServoID = CJointDef::JointID_LArm1 + m;
        iInfo.m_fSpeed = 0.2;
        iInfo.m_fPosition = 0.1;
        arm.push_back (iInfo);
    }
    SendArmGoToAngle (arm, unCmdSN);
#else
    PosFolded();
    while(1)
    {
        if(recvfrom_socket(3000, recv_socket3000, recvline3000))
        {
            if(strcmp(recvline3000, "exit") == 0)
            {
                close_socket(3000, recv_socket3000);
                break;
            }
            else if(strcmp(recvline3000, "POSORIG") == 0)
                PosOrig();
            else if(strcmp(recvline3000, "POSFOLDED") == 0)
                PosFolded();
            else if(strcmp(recvline3000, "POSWORKING") == 0)
                PosWorking();
            else if(strcmp(recvline3000, "POSSNAKE") == 0)
                PosSnake();
        }
    }
#endif

    return ;
}

inline eint test::PosOrig()
{
    euint unCmdSN;
    CAngleMoveInfo iInfo;
    std::vector<CAngleMoveInfo> arm;
    for(euint m = 0; m < HeptArmJointTotalNum; m++)
    {
        iInfo.Clear();
        iInfo.m_nServoID = CJointDef::JointID_LArm1 + m;
        iInfo.m_fSpeed = aspeed;

        switch(m)
        {
            // THE ORIGIN
            case 0: iInfo.m_fPosition = 0; break; // [-2.6274, 2.6274]
            case 1: iInfo.m_fPosition = 0; break; // [-1.7199, 1.1090]
            case 2: iInfo.m_fPosition = 0; break; // [-2.6100, 2.6100]
            case 3: iInfo.m_fPosition = 0; break; // [-1.7024, 1.7024]
            case 4: iInfo.m_fPosition = 0; break; // [-2.2086, 2.2086]
            case 5: iInfo.m_fPosition = 0; break; // [-1.9991, 1.9991]
            case 6: iInfo.m_fPosition = 0; break; // [-2.0000, 2.0000]
        }

        arm.push_back (iInfo);
    }

    SendArmGoToAngle (arm, unCmdSN);

    arm.clear();
    sleep(8);

    return ERR_NONE;
}

inline eint test::PosFolded()
{
    euint unCmdSN;
    CAngleMoveInfo iInfo;
    std::vector<CAngleMoveInfo> arm;
    for(euint m = 0; m < HeptArmJointTotalNum; m++)
    {
        iInfo.Clear();
        iInfo.m_nServoID = CJointDef::JointID_LArm1 + m;
        iInfo.m_fSpeed = aspeed;

        switch(m)
        {
            // FOLDED
            case 0: iInfo.m_fPosition = 2.6274; break; // [-2.6274, 2.6274]
            case 1: iInfo.m_fPosition = 1.4; break; // [-1.7199, 1.1090]
            case 2: iInfo.m_fPosition = -pi/2; break; // [-2.6100, 2.6100]
            case 3: iInfo.m_fPosition = -1.7024; break; // [-1.7024, 1.7024]
            case 4: iInfo.m_fPosition = 0; break; // [-2.2086, 2.2086]
            case 5: iInfo.m_fPosition = -1.7024; break; // [-1.9991, 1.9991]
            case 6: iInfo.m_fPosition = 0; break; // [-2.0000, 2.0000]
            }

        arm.push_back (iInfo);
    }

    SendArmGoToAngle (arm, unCmdSN);

    arm.clear();
    sleep(8);
	return ERR_NONE;
}

inline eint test::PosWorking()
{
    euint unCmdSN;
    CAngleMoveInfo iInfo;
    std::vector<CAngleMoveInfo> arm;
    for(euint m = 0; m < HeptArmJointTotalNum; m++)
    {
        iInfo.Clear ();
        iInfo.m_nServoID = CJointDef::JointID_LArm1 + m;
        iInfo.m_fSpeed = aspeed;

        switch(m)
        {
            // WORKING
            case 0: iInfo.m_fPosition = 0; break; // [-2.6274, 2.6274]
            case 1: iInfo.m_fPosition = -pi/2; break; // [-1.7199, 1.1090]
            case 2: iInfo.m_fPosition = 0; break; // [-2.6100, 2.6100]
            case 3: iInfo.m_fPosition = 0; break; // [-1.7024, 1.7024]
            case 4: iInfo.m_fPosition = pi/2; break; // [-2.2086, 2.2086]
            case 5: iInfo.m_fPosition = 0; break; // [-1.9991, 1.9991]
            case 6: iInfo.m_fPosition = -pi/6; break; // [-2.0000, 2.0000]
        }

        arm.push_back (iInfo);
    }

    SendArmGoToAngle (arm, unCmdSN);

    arm.clear();
    sleep(8);
    sendto_socket(2000, send_socket2000, "startgrab");
    sleep(2*60);
    sendto_socket(2000, send_socket2000, "stopgrab");
    return ERR_NONE;
}

inline eint test::PosSnake()
{
    euint unCmdSN;
    CAngleMoveInfo iInfo;
    std::vector<CAngleMoveInfo> arm;
    for(euint m = 0; m < HeptArmJointTotalNum; m++)
    {
        iInfo.Clear ();
        iInfo.m_nServoID = CJointDef::JointID_LArm1 + m;
        iInfo.m_fSpeed = aspeed;

        switch(m)
        {
            // SNAKE
            case 0: iInfo.m_fPosition = pi/2; break; // [-2.6274, 2.6274]
            case 1: iInfo.m_fPosition = -pi/2; break; // [-1.7199, 1.1090]
            case 2: iInfo.m_fPosition = 0; break; // [-2.6100, 2.6100]
            case 3: iInfo.m_fPosition = pi/4; break; // [-1.7024, 1.7024]
            case 4: iInfo.m_fPosition = 0; break; // [-2.2086, 2.2086]
            case 5: iInfo.m_fPosition = -pi/4; break; // [-1.9991, 1.9991]
            case 6: iInfo.m_fPosition = 0; break; // [-2.0000, 2.0000]
        }

        arm.push_back (iInfo);
    }

    SendArmGoToAngle (arm, unCmdSN);

    arm.clear();
    sleep(8);
    sendto_socket(2000, send_socket2000, "startgrab");
    sleep(2*60);
    sendto_socket(2000, send_socket2000, "stopgrab");
    return ERR_NONE;
}

void test::JobFailed(eint nErrCode)
{
    return ;
}

eint  test::ProcTimer(edouble dTimeStamp){
    // std::cout << "logic here" << std::endl;
    return ERR_NONE;
}



eint  test::ProcMotCmdDone(edouble dTimeStamp,CCmdDoneMessage* piCmdDone){

    return ERR_NONE;
}


eint  test::ProcArmPos(edouble dTimeStamp,CArmPosMessage* piArmPos){
    std::cout << "dTimeStamp = " << dTimeStamp << std::endl;

    for(euint i = 0 ; i < piArmPos->m_viArmJointList.size(); i++){
        std::cout << "Position of " << i << " is " << piArmPos->m_viArmJointList[i].m_dPosition << std::endl;

    }
    return ERR_NONE;
}

void test::WriteTraj(const echar* szFileName, std::vector<edouble> vPosition)
{
    if(0 != vPosition.size () % (MoRoArmJointTotalNum + 1))
    {
        return;
    }
    FILE* piFile = nullptr;
    piFile = fopen (szFileName, "w");

    if(nullptr == piFile)
    {
        return;
    }
    for(euint m = 0; m < vPosition.size (); m++)
    {
        fprintf (piFile, "%.4f", vPosition[m]);
        fprintf (piFile, "\t");
        if(0 == (m + 1) % (MoRoArmJointTotalNum + 1) && 0 != m)
        {
            fprintf (piFile, "\n");
        }
    }
    fclose(piFile);
}

