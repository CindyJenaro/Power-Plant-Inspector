#ifndef test_H
#define test_H

#include <EwayFunc/FuncInterface.h>
/* Server as Receiver */
#include<sys/socket.h>
#include<sys/types.h>
#include<unistd.h>
#include<arpa/inet.h>
#include<cstring>
using namespace std;

typedef int SOCKET;
typedef sockaddr SOCKADDR;

SOCKET init_recv_socket(int port);
SOCKET init_send_socket(int port);
bool recvfrom_socket(int port, SOCKET socket, char recvline[1024]);
void sendto_socket(int port, SOCKET socket, const char* message);
void close_socket(int port, SOCKET socket);

Declare_FunLibSymble

class test:public CFuncInterface
{
private:
    ebool Zero_flag;
    ebool moro2_flag = false;
    eint count;
public:
    test() {}
    virtual ~test() {}
    virtual eint Initialize(std::vector<eint> &vFeatureList,ebool &bLimbAuthority,edouble &dTimeOut);
    virtual eint Destroy();
    virtual eint CheckMsgCode(eint nMsgCode);

    virtual void JobStart();
    virtual void JobFailed(eint nErrCode);

    virtual eint ProcTimer(edouble dTimeStamp);
    virtual eint ProcMotCmdDone(edouble dTimeStamp,CCmdDoneMessage* piCmdDone);

    virtual eint ProcArmPos(edouble dTimeStamp,CArmPosMessage* piArmPos);
    inline eint PosOrig();
    inline eint PosFolded();
    inline eint PosWorking();
    inline eint PosSnake();

    void WriteTraj(const echar* szFileName, std::vector<edouble> vPosition);
    DECLEAR_FIFMESSAGE_MAP
};

#endif // test_H


